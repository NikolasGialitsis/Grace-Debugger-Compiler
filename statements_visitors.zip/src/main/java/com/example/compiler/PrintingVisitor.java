package com.example.compiler;

import com.example.compiler.analysis.DepthFirstAdapter;
import com.example.compiler.node.*;

import java.util.Collections;

/**
 * Created by alexandros on 24/3/2017.
 */
public class PrintingVisitor extends DepthFirstAdapter {
    // Hackish way to do indentations in visitors; there's probably a better way
    int indentation = 0;
    private void addIndentationLevel() {
        indentation++;
    }

    private void removeIndentationLevel() {
        indentation--;
    }

    private void printIndentation() {
        System.out.print(String.join("", Collections.nCopies(indentation, " ")));
    }

    @Override
    public void inABody(ABody node) {
        System.out.println("Entering AST");
        System.out.printf("Parse tree has %d top-level statements\n", node.getStmts().size());
    }

    @Override
    public void outABody(ABody node) {
        System.out.println("Exiting AST");
    }

    @Override
    public void inAIfStmt(AIfStmt node) {
        addIndentationLevel();

        printIndentation();
        System.out.println("Entering if statement");
        printIndentation();
        System.out.printf("Then branch has %d statements and else branch has %d statements\n",
                node.getThen().size(), node.getElse().size());
    }

    @Override
    public void outAIfStmt(AIfStmt node) {
        printIndentation();
        System.out.println("Exiting if statement");

        removeIndentationLevel();
    }

    @Override
    public void inAWhileStmt(AWhileStmt node) {
        addIndentationLevel();

        printIndentation();
        System.out.println("Entering while statement");
        printIndentation();
        System.out.printf("While statement body has %d statements\n", node.getBody().size());
    }

    @Override
    public void outAWhileStmt(AWhileStmt node) {
        printIndentation();
        System.out.println("Exiting while statement");

        removeIndentationLevel();
    }

    @Override
    public void inAAssignStmt(AAssignStmt node) {
        addIndentationLevel();

        printIndentation();
        System.out.printf("Assignment of variable %s\n", node.getVariable().getText());
    }

    @Override
    public void outAAssignStmt(AAssignStmt node) {
        removeIndentationLevel();
    }
}
