package com.example.compiler;

import com.example.compiler.analysis.DepthFirstAdapter;
import com.example.compiler.node.AAssignStmt;
import com.example.compiler.node.Node;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by alexandros on 24/3/2017.
 */
public class VariableVisitor extends DepthFirstAdapter {
    private Set<String> variables = new HashSet<>();

    @Override
    public void inAAssignStmt(AAssignStmt node) {
        variables.add(node.getVariable().getText());
    }

    public static Set<String> allVariableNames(Node root) {
        VariableVisitor visitor = new VariableVisitor();
        root.apply(visitor);

        return Collections.unmodifiableSet(visitor.variables);
    }
}
