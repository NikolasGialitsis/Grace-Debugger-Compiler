package com.example.compiler;

import com.example.compiler.analysis.DepthFirstAdapter;
import com.example.compiler.node.AType;

/**
 * Created by alexandros on 25/3/2017.
 */
public class GenericsVisitor extends DepthFirstAdapter {
    private int indent = 0;

    @Override
    public void inAType(AType node) {
        for (int i = 0; i < indent; i++) {
            System.out.print(' ');
        }

        System.out.println(node.getName().getText());

        indent++;
    }

    @Override
    public void outAType(AType node) {
        indent--;
    }
}
