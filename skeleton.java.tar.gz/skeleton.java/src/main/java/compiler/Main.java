
package compiler;

class Main { 

	void main(String args[]) { 

	}

}
