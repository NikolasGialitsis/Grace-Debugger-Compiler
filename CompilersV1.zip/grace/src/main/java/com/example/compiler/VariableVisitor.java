package com.example.compiler;

import com.example.compiler.analysis.DepthFirstAdapter;
import com.example.compiler.node.ALvalStmt;
import com.example.compiler.node.Node;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class VariableVisitor extends DepthFirstAdapter {
    private Set<String> variables = new HashSet<>();

    @Override
    public void inALvalStmt(ALvalStmt node) {
        variables.add(node.getLvalue().toString());
    }

    public static Set<String> allVariableNames(Node root) {
        VariableVisitor visitor = new VariableVisitor();
        root.apply(visitor);

        return Collections.unmodifiableSet(visitor.variables);
    }
}
