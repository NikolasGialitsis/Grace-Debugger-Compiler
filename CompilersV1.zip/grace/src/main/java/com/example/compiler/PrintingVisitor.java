package com.example.compiler;

import com.example.compiler.analysis.DepthFirstAdapter;
import com.example.compiler.node.*;

import java.util.Collections;

public class PrintingVisitor extends DepthFirstAdapter {

    int indentation = 0;

    private void addIndentationLevel(int x ) {

        indentation+= x;
    }
    private void addIndentationLevel() {
        indentation++;
    }

    private void removeIndentationLevel(int x) {
        indentation-=x;
    }
    private void removeIndentationLevel() {
        indentation--;
    }
    private void printIndentation() {
        System.out.print(String.join("", Collections.nCopies(indentation, " ")));
    }

    @Override
    public void inAGoalGoal(AGoalGoal node) {
        System.out.println("<Program> :");
        addIndentationLevel();
    }

    @Override
    public void outAGoalGoal(AGoalGoal node){
        removeIndentationLevel();
        System.out.println("</Program> ");
    }


    @Override
    public void inALvalStmt(ALvalStmt node) {
        printIndentation();
        System.out.printf("[assign] %s %s %s  \n", node.getLvalue(),node.getAssign(),node.getExpr());
        printIndentation();
        System.out.printf("   lvalue : %s \n",node.getLvalue());
        printIndentation();
        System.out.printf("   expr : %s\n",node.getExpr());
    }


    @Override
    public void inAExprplExpr(AExprplExpr node) {
        printIndentation();
        System.out.printf("  plus : %s %s %s \n", node.getExpr(), node.getPlus(), node.getExprTerm());
    }


    @Override
    public void inAExprminExpr(AExprminExpr node) {
        printIndentation();
        System.out.printf("  minus : %s %s %s \n", node.getExpr(), node.getMinus(), node.getExprTerm());
    }

    @Override
    public void inAExprmodpExprTermPars(AExprmodpExprTermPars node)
    {
        printIndentation();
        System.out.printf("  mod  : (%s %s %s)\n", node.getFactor(),node.getMod(),node.getFac2());
    }

    @Override
    public void inAExprdivpExprTermPars(AExprdivpExprTermPars node)
    {
        printIndentation();
        System.out.printf("  div : (%s %s %s)\n", node.getFactor(),node.getDiv(),node.getFac2());
    }


    @Override
    public void inAExprmulpExprTermPars(AExprmulpExprTermPars node)
    {
        printIndentation();
        System.out.printf("  mul : (%s %s %s)\n", node.getFactor(),node.getMult(),node.getFac2());
    }

    @Override
    public void inAExprplparExprTermPars(AExprplparExprTermPars node)
    {
        printIndentation();
        System.out.printf("  plus : (%s %s %s )\n", node.getExpr(),node.getPlus(),node.getExprTerm());
    }


    @Override
    public void inAExprminparExprTermPars(AExprminparExprTermPars node)
    {
        printIndentation();
        System.out.printf("  minus : (%s %s %s )\n", node.getExpr(),node.getMinus(),node.getExprTerm());
    }

    @Override
    public void inAIfThenElseIfStmt(AIfThenElseIfStmt node)
    {
        addIndentationLevel();
        printIndentation();
        System.out.printf("[If/else] :\n");
    }

    @Override
    public void outAIfThenElseIfStmt(AIfThenElseIfStmt node){
        removeIndentationLevel();
    }

    @Override
    public void inAIfThennotIfStmt(AIfThennotIfStmt node)
    {
        addIndentationLevel();
        printIndentation();
        System.out.printf("[If not] :\n");
    }

    @Override
    public void outAIfThennotIfStmt(AIfThennotIfStmt node){
        removeIndentationLevel();
    }

    @Override
    public void inAIfThenElsenotIfStmt(AIfThenElsenotIfStmt node)
    {
        addIndentationLevel();
        printIndentation();
        System.out.printf("[If not/else] :\n");

    }

    @Override
    public void outAIfThenElsenotIfStmt(AIfThenElsenotIfStmt node)
    {
        removeIndentationLevel();
    }

    @Override
    public void inAIfThenIfStmt(AIfThenIfStmt node){
        addIndentationLevel();
        printIndentation();
        System.out.printf("[If] :\n");
    }
    @Override
    public void outAIfThenIfStmt(AIfThenIfStmt node){
        removeIndentationLevel();
    }

    @Override
    public void inAWhileStmt(AWhileStmt node)
    {

        addIndentationLevel();
        printIndentation();
        System.out.printf("[While]:\n");

    }

    @Override
    public void outAWhileStmt(AWhileStmt node){
        removeIndentationLevel();
    }
    @Override
    public void inAWhileElseStmtWithElse(AWhileElseStmtWithElse node)
    {
        addIndentationLevel();
        printIndentation();
        System.out.printf("[While/else] : \n");
    }

    @Override
    public void outAWhileElseStmtWithElse(AWhileElseStmtWithElse node){
        removeIndentationLevel();
    }

    @Override
    public void inAFuncDefFuncDef(AFuncDefFuncDef node)
    {
        addIndentationLevel();
        printIndentation();
        System.out.printf("[Func Def] : \n");
        addIndentationLevel();
    }

    @Override
    public void outAFuncDefFuncDef(AFuncDefFuncDef node){
        removeIndentationLevel(2);
    }

    @Override
    public void inAHeaderHeader(AHeaderHeader node)
    {
        printIndentation();
        System.out.printf("[Header] : %s %s \n",node.getFun(),node.getId(),node.getManyArgs());
        addIndentationLevel();
        printIndentation();
        System.out.printf(" return type : %s\n",node.getRetType());
        addIndentationLevel();


    }

    @Override
    public void outAHeaderHeader(AHeaderHeader node){
        removeIndentationLevel(0);
    }


    @Override
    public void inABlockDefBlock(ABlockDefBlock node)
    {
        addIndentationLevel(2);
        printIndentation();
        System.out.println("<Block> : ");
        addIndentationLevel(3);
    }

    @Override
    public void outABlockDefBlock(ABlockDefBlock node)
    {
        removeIndentationLevel(3);
        printIndentation();
        System.out.println("</Block>  ");
        removeIndentationLevel(2);
    }

    @Override
    public void inAFuncallStmt(AFuncallStmt node)
    {
        printIndentation();
        System.out.printf("func_call : \n");
        addIndentationLevel();
    }

    @Override
    public void outAFuncallStmt(AFuncallStmt node)

    {
        removeIndentationLevel();
    }

    @Override
    public void inAExprListExprList(AExprListExprList node)
    {

       printIndentation();
       if (node.getCommaExpr() != null && node.getCommaExpr().toString() != "[]")
           System.out.printf("   exprs :  %s  %s\n",node.getExpr(),node.getCommaExpr());
       else
           System.out.printf("   expr :  %s  \n",node.getExpr());
    }

    public void outAExprListExprList(AExprListExprList node)
    {
        defaultOut(node);
    }



    @Override
    public void inACondandCond(ACondandCond node)
    {
        printIndentation();
        if(node.getNot() == null || node.getNot().toString() == "[]")
            System.out.printf("  and : %s %s %s \n", node.getCond(), node.getAnd(),node.getCondTerm());
        else
            System.out.printf("  and : %s %s %s %s \n", node.getCond(), node.getAnd(),node.getNot(),node.getCondTerm());
    }

    @Override
    public void inACondorCond(ACondorCond node)
    {
        printIndentation();
        if(node.getNot() == null || node.getNot().toString() == "[]")
            System.out.printf("  or : %s %s %s \n", node.getCond(), node.getOr(),node.getCondTerm());
        else
            System.out.printf("  or : %s %s %s %s \n", node.getCond(), node.getOr(),node.getNot(),node.getCondTerm());
    }

    @Override
    public void inACondandparCond(ACondandparCond node)
    {
        printIndentation();
        if(node.getNot() == null || node.getNot().toString() == "[]")
            System.out.printf("  and : %s %s %s \n", node.getCond(), node.getAnd(),node.getCondTermPars());
        else
            System.out.printf("  and : %s %s %s %s \n", node.getCond(), node.getAnd(),node.getNot(),node.getCondTermPars());
    }

    @Override
    public void inACondorparCond(ACondorparCond node)
    {
        printIndentation();
        if(node.getNot() == null || node.getNot().toString() == "[]")
            System.out.printf("  or : %s %s %s \n", node.getCond(), node.getOr(),node.getCondTermPars());
        else
            System.out.printf("  or : %s %s %s %s \n", node.getCond(), node.getOr(),node.getNot(),node.getCondTermPars());
    }

    @Override
    public void inANnNotCond(ANnNotCond node)
    {
        printIndentation();
        System.out.printf("  and : (%s %s) \n", node.getNot(),node.getCond());
    }

    @Override
    public void inANn1NotCond(ANn1NotCond node)
    {
        printIndentation();
        System.out.printf("  and : %s %s \n", node.getNot(),node.getCond());
    }

    @Override
    public void inANn2NotCond(ANn2NotCond node)
    {
        printIndentation();
        System.out.printf("  and : %s %s \n", node.getNot(),node.getNotCond());
    }

    @Override
    public void inAEqualparCondTermPars(AEqualparCondTermPars node)
    {
        printIndentation();
        if(node.getNot() != null && node.getNot().toString() != "[]")
            System.out.printf("  equal : %s (%s %s %s) \n", node.getNot(),node.getExpr(),node.getEqual(),node.getFac2());
        else
            System.out.printf("  equal : (%s %s %s) \n",node.getExpr(),node.getEqual(),node.getFac2());
    }

    @Override
    public void inALessparCondTermPars(ALessparCondTermPars node)
    {
        printIndentation();
        if(node.getNot() != null && node.getNot().toString() != "[]")
            System.out.printf("  less : %s (%s %s %s) \n", node.getNot(),node.getExpr(),node.getLess(),node.getFac2());
        else
            System.out.printf("  less : (%s %s %s) \n",node.getExpr(),node.getLess(),node.getFac2());
    }

    @Override
    public void inAGreaterparCondTermPars(AGreaterparCondTermPars node)
    {
        printIndentation();
        if(node.getNot() != null && node.getNot().toString() != "[]")
            System.out.printf("  greater : %s (%s %s %s) \n", node.getNot(),node.getExpr(),node.getGreater(),node.getFac2());
        else
            System.out.printf("  greater : (%s %s %s) \n",node.getExpr(),node.getGreater(),node.getFac2());
    }


    @Override
    public void inAGreateqparCondTermPars(AGreateqparCondTermPars node)
    {
        printIndentation();
        if(node.getNot() != null && node.getNot().toString() != "[]")
            System.out.printf("  greater_eq : %s (%s %s %s) \n", node.getNot(),node.getExpr(),node.getGreaterEqual(),node.getFac2());
        else
            System.out.printf("  greater_eq : (%s %s %s) \n",node.getExpr(),node.getGreaterEqual(),node.getFac2());
    }

    @Override
    public void inALessequalparCondTermPars(ALessequalparCondTermPars node)
    {
        printIndentation();
        if(node.getNot() != null && node.getNot().toString() != "[]")
            System.out.printf("  less_eq : %s (%s %s %s) \n", node.getNot(),node.getExpr(),node.getLessEqual(),node.getFac2());
        else
            System.out.printf("  less_eq : (%s %s %s) \n",node.getExpr(),node.getLessEqual(),node.getFac2());
    }

    @Override
    public void inAEqualCondTerm(AEqualCondTerm node)
    {
        printIndentation();
        System.out.printf("   equal : %s %s %s\n",node.getExpr(),node.getEqual(),node.getFac2());
    }

    @Override
    public void inAHashCondTerm(AHashCondTerm node)
    {
        printIndentation();
        System.out.printf("   hash : %s %s %s\n",node.getExpr(),node.getHashtag(),node.getFac2());
    }

    @Override
    public void inALessCondTerm(ALessCondTerm node)
    {
        printIndentation();
        System.out.printf("   less : %s %s %s\n",node.getExpr(),node.getLess(),node.getFac2());
    }

    @Override
    public void inAGreaterCondTerm(AGreaterCondTerm node)
    {
        printIndentation();
        System.out.printf("   greater : %s %s %s\n",node.getExpr(),node.getGreater(),node.getFac2());
    }

    @Override
    public void inALessequalCondTerm(ALessequalCondTerm node)
    {
        printIndentation();
        System.out.printf("   less_eq : %s %s %s\n",node.getExpr(),node.getLessEqual(),node.getFac2());
    }
    @Override
    public void inAGreateqCondTerm(AGreateqCondTerm node)
    {
        printIndentation();
        System.out.printf("   greater_eq : %s %s %s\n",node.getExpr(),node.getGreaterEqual(),node.getFac2());
    }

    @Override
    public void inAVarDefVarDef(AVarDefVarDef node)
    {
        printIndentation();
        if(node.getCommaId() != null && node.getCommaId().toString() != "[]") {
            System.out.printf("   var_def : %s %s %s %s %s\n", node.getVar(), node.getId(), node.getCommaId(), node.getColon(), node.getType());
        }
        else {
            System.out.printf("   var_def : %s %s %s %s\n", node.getVar(), node.getId(),  node.getColon(), node.getType());
        }
    }

    @Override
    public void inAReturnStmt(AReturnStmt node)
    {
        printIndentation();
        if(node.getExpr() != null && node.getExpr().toString() != "[]"){
            System.out.printf("   return : %s %s\n",node.getReturn(),node.getExpr());
        }
        else {
            System.out.printf("   return : %s\n",node.getReturn());
        }

    }

    @Override
    public void inAFuncFuncCall(AFuncFuncCall node)
    {
        printIndentation();
        System.out.printf("   func_name : %s\n",node.getId());
    }

    @Override
    public void inAFparDefFparDef(AFparDefFparDef node)
    {
        printIndentation();
        if(node.getRef() != null && node.getRef().toString() != "[]") {
            if(node.getCommaId() != null && node.getCommaId().toString() != "[]") {
                System.out.printf("[args] %s  %s :by reference\n", node.getId(), node.getCommaId());
            }
            else {
                System.out.printf("[arg] %s :by reference\n", node.getId());
            }
        }
        else {
            if(node.getCommaId() != null && node.getCommaId().toString() != "[]") {
                System.out.printf("[args] %s  %s :by value\n", node.getId(), node.getCommaId());
            }
            else {
                System.out.printf("[arg] %s :by value\n", node.getId());
            }
        }
    }

}
