/* Author @Nikolas Gialitsis:sdi1400027@di.uoa.gr */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "header.h"
#include <sys/wait.h>
#include <signal.h>



int main(int argc , char** argv){



	errno = 0;
	int job_num = 0;
	char * token = NULL;
	char* input = calloc(strlen(argv[1])+1,1);
	int pool_id = atoi(argv[2]);
	int max_jobs = atoi(argv[3]);
	int log_id = atoi(argv[4]);
	if(input == NULL){
		perror("Memory Allocation");
		exit(5);
	}

	if ( strcpy(input,argv[1]) < 0 ){
		perror("strcpy");
		exit(4);
	}

	if ( (token = strtok(input," \n")) < 0){
		perror("strtok");
		exit(-12);
	}


	Job* jobs ;
	if ( ( jobs = calloc(max_jobs*sizeof(Job),1)) == NULL){
		perror("Memory Allocation");
	}
	int k;
	for( k = 0 ; k < max_jobs ; k++){
		jobs[k].id = -1;
		jobs[k].pid = -1;
	}


	char* out_pool = calloc(strlen("out_pool")+1+strlen("10000"),1);
	if(out_pool == NULL){
		perror("Memory Allocation");
		exit(5);
	}

	if( sprintf(out_pool,"out_pool%d",pool_id) < 0 ){
		perror("sprintf");
		exit(14);
	}




	int fd_out;
	if ( (fd_out = open(out_pool,O_WRONLY,PERMS) ) < 0 ){
		perror("open out_pool");
		exit(-3);
	}


	char* in_pool = calloc(strlen("in_pool")+1+strlen("10000"),1);
	if(in_pool == NULL){
		perror("Memory Allocation");
		exit(5);
	}

	if( sprintf(in_pool,"in_pool%d",pool_id) < 0 ){
		perror("sprintf");
		exit(14);
	}




	int fd_in;
	if ( (fd_in = open(in_pool,O_RDONLY|O_NONBLOCK,PERMS) ) < 0 ){
		perror("open in_pool");
		exit(-3);
	}

	char* string = NULL;
	while(1){
		if(job_num != 0){
			string = calloc(MAXREAD,1);
			if(string == NULL){
				perror("Memory Allocation");
				exit(5);
			}
			while(read(fd_in,string,MAXREAD) <= 0){
				if(errno == EAGAIN){
					errno = 0;
				}
				else if(errno != 0){
					perror("Error");
					exit(111);
				}
				else ;
			}
			char* temp = calloc(strlen(string)+1,1);
			strcpy(temp,string);
			token = strtok(string," \n");

		}
		else{
			string = calloc(strlen(token)+1,1);
			strcpy(string,token);
		}
		if(strcmp(string,"submit") == 0){
			

			char* job_to_exec = calloc(MAXREAD,1); 
			if(job_to_exec == NULL){
				perror("Memory Allocation");
				exit(5);
			}

			while(token != NULL){
				if ( (token = strtok(NULL," \n")) < 0){
					perror("strtok");
					exit(-12);
				}

				if(token != NULL){
					char* new_arg ;
					if ( ( new_arg = calloc(strlen(token)+5,1) ) == NULL ){
						perror("Memory Allocation");
						exit(5);
					}
					
					if (sprintf(new_arg,"%s ",token) < 0 ){
						perror("sprintf");
						exit(-15);
					}
					strcat(job_to_exec,new_arg);
				}

			}
		
			pid_t pid = fork();
			if( pid < 0 ){
				perror("Fork");
				exit(-11);
			}
			else if(pid == 0 ){
				
				char* charb = calloc(strlen(job_to_exec)+1,1);
				strcpy(charb,job_to_exec);

				char* command = strtok(charb," -");
				if(command == NULL)command = job_to_exec;

				
				char** args = calloc(MAXREAD,1);
				if(args == NULL){
					perror("Memory Allocation");
					exit(5);
				}

				int argnum = 0;
				char* x = job_to_exec;
				while((token = strtok(x," \n")) != NULL){																									
					args[argnum] = calloc(strlen(token)+1,1);
					strcpy(args[argnum],token);																																																																																																																																																																																																													
					argnum++;
					x = NULL;
				}
				args[argnum] = NULL;																																																																																																																																																																																																																																						
				execvp(command,args);
				printf("return not expected \n");
				exit(-11);
			}
			jobs[job_num].id = job_num+log_id;
			jobs[job_num].pid = pid;
			char result[20];
			sprintf(result,"JobID : %d,PID : %d",job_num+log_id,pid);
			if ( write(fd_out,result,strlen(result)) < 0 ){
				perror("Write");
				exit(-32);
			}		
			job_num++;
		}

		else if ( (strcmp(string,"status") == 0)||((strcmp(string,"status-all"))==0 )){
			
			int job_id = -2;
			if(strcmp(string,"status")==0)job_id = atoi(strtok(NULL,"\n"));
			int status;
			int i;

			char* response = calloc(MAXREAD,1) ;
			if(response == NULL){
				perror("Memory Allocation");
				exit(5);
			}
			char* old_response = calloc(MAXREAD,1) ;
			if(old_response == NULL){
				perror("Memory Allocation");
				exit(5);
			}

			int j = 0 ;
			for(j = 0 ; j < MAXREAD ; j++)	
			{
				response[j] = 0;	
				old_response[j] = 0;	
			}

			for( i = 0 ; i < max_jobs ; i++){ 
				if((jobs[i].id == job_id)||(strcmp(string,"status-all")==0)){
					if((jobs[i].id == -1)||(jobs[i].pid == -1))continue;
					pid_t pid = waitpid(jobs[i].pid, &status, WNOHANG|WUNTRACED|WCONTINUED );
					char temp[50];
					int j;
					for(j = 0 ; j < 50 ; j++)temp[j] = 0;
					
					if(pid < 0 ){
					    perror("Waitpid");
					    write(fd_out,"ERROR\n",strlen("ERROR\n"));	
					}
					else if (pid == 0) {
						sprintf(temp,"JobID %d : ACTIVE",jobs[i].id);		
					}
					else if (pid == jobs[i].pid) {
	              		if (WIFEXITED(status)){
							sprintf(temp,"JobID %d : FINISHED",jobs[i].id);
						}
		              	else if (WIFSIGNALED(status)){
							sprintf(temp,"JobID %d : SIGNALED",jobs[i].id);
						}
		              	else if (WIFSTOPPED(status)){
							sprintf(temp,"JobID %d : STOPPED",jobs[i].id);
						}
					}
					else {
							sprintf(temp,"JobID %d : ERROR",jobs[i].id);
					}	
					if(strcmp(string,"status")==0){
						strcpy(response,temp);
						break;
					}
					else if(strcmp(string,"status-all")==0){
						if(i == 0){
							strcpy(old_response,temp);
							strcpy(response,temp);
						}
						else{
							sprintf(response,"%s\n%s",old_response,temp);
							strcpy(old_response,response);
						}
					}

				}

			}
			
			write(fd_out,response,strlen(response));
			if(response != NULL)free(response);
			if(old_response!=NULL)free(old_response);
		}
		else {
			write(fd_out,"ERROR\n",strlen("ERROR\n"));	
		}
		
		token = NULL;
	}
	if ( close(fd_out) < 0 ){
		perror("Close fd_out");
		exit(2);
	}	
	if ( close(fd_in) < 0 ){
		perror("Close fd_in");
		exit(2);
	}	
	printf("pool %d exiting\n",pool_id );
	free(jobs);
	exit(0) ;
}