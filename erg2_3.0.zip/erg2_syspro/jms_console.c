/* Author @Nikolas Gialitsis:sdi1400027@di.uoa.gr */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "header.h"

int main(int argc ,char** argv){
	errno = 0;
	if ( argc < 5){
		perror("Not enough arguments given as input");
		exit(-1);
	}

	char* jms_in = NULL;
	char* jms_out = NULL;
	char* operations_file = NULL; 
	int i;
	for(i = 1 ; i < argc ; i++){
		if( strcmp(argv[i],"-w") == 0 ){
			jms_in = argv[i+1];
			i++;
		}
		else if( strcmp(argv[i],"-r") == 0 ){
			jms_out = argv[i+1];
			i++; 
		}
		else if( strcmp(argv[i],"-o") == 0 ){
			operations_file = argv[i+1];
			i++;
		}
		else {
			perror("Uknown input");
			printf("\n\n");
		}
	}
	if ( (jms_in == NULL) || (jms_out == NULL) || ( errno != 0)){
		perror("Unexpected Behaviour");
		exit(-1);
	}


	FILE* fd_op ;


	int fd_in;
	if ( (fd_in = open(jms_in,O_WRONLY,PERMS) ) < 0 ){
		perror("open jms_in");
		exit(-3);
	}

	int fd_out;
	if ( (fd_out = open(jms_out,O_RDONLY,PERMS) ) < 0 ){
		perror("open jms_out");
		exit(-3);
	}

	
	if(operations_file != NULL){
		char* buf = NULL;
		fd_op = fopen(operations_file,"rb");
		if (errno != 0 ){
			perror("open operations_file");
			exit(-3);
		}

		buf = calloc(MAXREAD,1);
		if(buf == NULL){
			perror("Memory Allocation");
			exit(5);
		}
		
		if( fread(buf,MAXREAD,1,fd_op) < 0 ){
			perror("read operations_file");
			exit(-9);
		}

		if (fclose(fd_op) < 0 ){
			perror("Close operations_file");
			exit(-MAXREAD);
		}

		char* input;
		char * x = buf;
		while((input = strtok(x,"\n"))!= NULL){
			x = NULL;
			if((input != NULL)&&(strcmp(input," ")!= 0)&&(strcmp(input,"\n")!=0)){
				write(fd_in,input,MAXREAD);
			}
			else continue;

			char* response = calloc(MAXPOOLS*MAXREAD,1);
			if(response == NULL){
				perror("Memory Allocation");
				exit(-5);
			}
			int k;
			for(k = 0 ; k < MAXPOOLS*MAXREAD ; k++)response[k] = 0;
			if(read(fd_out,response,MAXPOOLS*MAXREAD) < 0){
				perror("Read");
				exit(-36);
			}
			printf("Console:\n%s\n\n",response );

			if ( write(fd_in,buf,MAXREAD) < 0){
				perror("write jms_in");
				exit(-3);
			}
			free(response);
		}

	}
	while(feof(stdin) ==  0){
		char* input;
		if(  ( input = calloc(MAXREAD,1) ) == NULL){
			perror("Memory Allocation");
			exit(5);
		}
		fgets(input,MAXREAD,stdin);
		if((input != NULL)&&(strcmp(input," ")!= 0)&&(strcmp(input,"\n")!=0)){
			write(fd_in,input,MAXREAD);
			if(input != NULL)free(input);
		}
		else continue;

		char* response = calloc(MAXPOOLS*MAXREAD,1);
		if(response == NULL){
			perror("Memory Allocation");
			exit(-5);
		}
		int k;
		for(k = 0 ; k < MAXPOOLS*MAXREAD ; k++)response[k] = 0;
		if(read(fd_out,response,MAXPOOLS*MAXREAD) < 0){
			perror("Read");
			exit(-36);
		}
		printf("Console:\n%s\n\n",response );
		free(response);			

	}

	if ( close(fd_in) < 0 ){
		perror("Close fd_in");
		exit(2);
	}	
	if ( close(fd_out) < 0 ){
		perror("Close fd_out");
		exit(2);
	}	
	printf("\n");
	exit(0);
}