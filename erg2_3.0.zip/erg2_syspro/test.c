#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>


int main(int argc,char** argv){
	if(argc != 2)exit(-1);
	sleep(atoi(argv[1]));
	exit(0);
}