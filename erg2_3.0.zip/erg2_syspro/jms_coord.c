/* Author @Nikolas Gialitsis:sdi1400027@di.uoa.gr */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "header.h"
#include <sys/wait.h>

int main(int argc ,char** argv){

	if ( argc < 9){
		perror("Not enough arguments given as input");
		exit(-1);
	}
	errno = 0;

	char* jms_in = NULL;
	char* jms_out = NULL;
	char* path = NULL;
	int jobs_pool = -1;

	int i;
	for(i = 1 ; i < argc ; i++){
		if( strcmp(argv[i],"-w") == 0 ){
			jms_in = argv[i+1];
			i++;
		}
		else if( strcmp(argv[i],"-r") == 0 ){
			jms_out = argv[i+1];
			i++; 
		}
		else if( strcmp(argv[i],"-n") == 0 ){
			jobs_pool = atoi(argv[i+1]);
			i++;
		}
		else if( strcmp(argv[i],"-l") == 0 ){
			path = argv[i+1];
			i++;
		}		
		else {
			perror("Uknown input");
			printf("\n\n");
		}
	}
	if ( (jms_in == NULL) || (jms_out == NULL) || (path == NULL) || (jobs_pool == -1)||(errno !=0 )){
		perror("Unexpected Behaviour");
		exit(-1);
	}


	struct stat statbuff;
	if ( stat(jms_in,&statbuff) >= 0 ) {
		if(errno != 0){
			perror("Stat");
			exit(6);
		}
		if ( unlink(jms_in) < 0 ){
			perror("Unlink");
			exit(7);
		}
	}
	else {
		if(errno != ENOENT){
			perror("Stat");
			exit(6);
		}
		errno = 0;
	}



	mkfifo(jms_in,PERMS);
	if (errno != 0 ){
		perror("mkfifo jms_in");
		exit(-2);
	}

	int fd_in;
	if ( (fd_in = open(jms_in,O_RDONLY|O_NONBLOCK,PERMS) ) < 0){
		perror("open jms_in");
		exit(-3);
	}
	char* charbuf = NULL;
	char * response = calloc(MAXPOOLS * MAXREAD,1);
	if(response == NULL){
		perror("Memory Allocation");
		exit(5);
	}

	int fd_out;

	if ( stat(jms_out,&statbuff) >= 0 ) {
		if(errno != 0){
			perror("Stat");
			exit(6);
		}
		if ( unlink(jms_out) < 0 ){
			perror("Unlink");
			exit(7);
		}
	}
	else {
		if(errno != ENOENT){
			perror("Stat");
			exit(6);
		}
		errno = 0;
	}



	mkfifo(jms_out,PERMS);
	if (errno != 0 ){
		perror("mkfifo jms_out");
		exit(-2);
	}

	if ( (fd_out = open(jms_out,O_WRONLY,PERMS) ) < 0){
		perror("open jms_out");
		exit(-3);
	}



	Pool* pool_table = NULL;
	char* job = NULL;

	int pool_id = 0; 
	int process_id = 0;
	while(1){

		if(charbuf != NULL)free(charbuf);
		if ( (charbuf = calloc(MAXREAD,1)) == NULL){
			perror("Memory Allocation");
			exit(5);
		}
		
		while(read(fd_in,charbuf,MAXREAD) < 0);
		errno = 0;
		job = charbuf;

		if(pool_table == NULL){
			if ( (pool_table = calloc(sizeof(Pool),1)) == NULL ){
				perror("Memory Allocation");
				exit(5);
			}
			pool_table[pool_id].id = pool_id;
			pool_table[pool_id].capacity = jobs_pool;


			char id_str[15];
			sprintf(id_str,"%d",pool_table[pool_id].id);
			char jobs_pool_str[15];
			sprintf(jobs_pool_str,"%d",jobs_pool);

			char* out_pool = calloc(strlen("out_pool")+1+strlen("10000"),1);
			if(out_pool == NULL){
				perror("Memory Allocation");
				exit(5);
			}

			if( sprintf(out_pool,"out_pool%d",pool_table[pool_id].id) < 0 ){
				perror("sprintf");
				exit(14);
			}
			struct stat statbuff;
			if ( stat(out_pool,&statbuff) >= 0 ) {
				if(errno != 0){
					perror("Stat");
					exit(6);
				}
				if ( unlink(out_pool) < 0 ){
					perror("Unlink");
					exit(7);
				}
			}
			else {
				if(errno != ENOENT){
					perror("Stat");
					exit(6);
				}
				errno = 0;
			}


			if (mkfifo(out_pool,PERMS) < 0){
				perror("mkfifo out_pool");
				exit(-2);
			}


			int fd_pool_out;
			if ( (fd_pool_out = open(out_pool,O_RDONLY|O_NONBLOCK,PERMS) ) < 0 ){
				perror("open out_pool");
				exit(-3);	
			}

			char* in_pool = calloc(strlen("in_pool")+1+strlen("10000"),1);
			if(in_pool == NULL){
				perror("Memory Allocation");
				exit(5);
			}

			if( sprintf(in_pool,"in_pool%d",pool_table[pool_id].id) < 0 ){
				perror("sprintf");
				exit(14);
			}
		
			if ( stat(in_pool,&statbuff) >= 0 ) {
				if(errno != 0){
					perror("Stat");
					exit(6);
				}
				if ( unlink(in_pool) < 0 ){
					perror("Unlink");
					exit(7);
				}
			}
			else {
				if(errno != ENOENT){
					perror("Stat");
					exit(6);
				}
				errno = 0;
			}


			if (mkfifo(in_pool,PERMS) < 0){
				perror("mkfifo in_pool");
				exit(-2);
			}



			pid_t pid = -1;
			pid = fork();
			if(pid == 0){ 
				char process_id_str[15];
				sprintf(process_id_str,"%d",process_id);
				execl("./pool","./pool",job,(char*)id_str,(char*)jobs_pool_str,(char*)process_id_str,(char*)NULL);
				printf("return not expected\n");
				exit(-11);
			}
			else if(pid < 0){
				perror("Fork");
				exit(-8);
			}
			else ;

			char* command = calloc(strlen(job)+1,1);
			strcpy(command,job);
			command = strtok(command," ");
			if(strcmp(command,"submit") == 0){
				process_id += jobs_pool;
				pool_table[pool_id].capacity--;
			}			

			int fd_pool_in;
			if ( (fd_pool_in = open(in_pool,O_WRONLY,PERMS) ) < 0 ){
				perror("open in_pool");
				exit(-3);
			}
			int j;
			int flag = 0;

			for(j = 0 ; j < MAXPOOLS * MAXREAD ; j++)response[j]=0;
			while(!flag){	
				if (read(fd_pool_out,response,MAXREAD) < 0 ){
					if(errno == EAGAIN)errno = 0;
					else {
						perror("Error");
						exit(111);
					}
				}
				else flag = 1;
			}
		}
		else{
			int found = 0;
			int k;
			char* command = calloc(strlen(job),1);
			strcpy(command,job);
			command = strtok(command," ");

			for (k = 0 ; k < pool_id + 1 ; k++){	
				if(pool_table[k].capacity > 0 ){			
					found = 1;
					break;
				}
			}

			if(!found && (strtok(command,"submit") == 0)){		
				if( (pool_table = realloc(pool_table,(k+1)*sizeof(Pool)) ) == NULL ){
					perror("Memory Reallocation");
					exit(5);
				}
				pool_table[k].id = k;
				pool_table[k].capacity = jobs_pool;				


				char* out_pool = calloc(strlen("out_pool")+1+strlen("10000"),1);
				if(out_pool == NULL){
					perror("Memory Allocation");
					exit(5);
				}

				if( sprintf(out_pool,"out_pool%d",pool_table[k].id) < 0 ){
					perror("sprintf");
					exit(14);
				}


				errno = 0;
				struct stat statbuff;
				if ( stat(out_pool,&statbuff) >= 0 ) {
					if(errno != 0){
						perror("Stat");
						exit(6);
					}
					if ( unlink(out_pool) < 0 ){
						perror("Unlink");
						exit(7);
					}
				}
				else {
					if(errno != ENOENT){
						perror("Stat");
						exit(6);
					}
					errno = 0;
				}


				if (mkfifo(out_pool,PERMS) < 0){
					perror("mkfifo out_pool");
					exit(-2);
				}

				int fd_pool_out;
				if ( (fd_pool_out = open(out_pool,O_RDONLY|O_NONBLOCK,PERMS) ) < 0 ){
					perror("open out_pool");
					exit(-3);
				}

				char* in_pool = calloc(strlen("in_pool")+1+strlen("10000"),1);
				if(in_pool == NULL){
					perror("Memory Allocation");
					exit(5);
				}

				if( sprintf(in_pool,"in_pool%d",pool_table[k].id) < 0 ){
					perror("sprintf");
					exit(14);
				}
			
				if ( stat(in_pool,&statbuff) >= 0 ) {
					if(errno != 0){
						perror("Stat");
						exit(6);
					}
					if ( unlink(in_pool) < 0 ){
						perror("Unlink");
						exit(7);
					}
				}
				else {
					if(errno != ENOENT){
						perror("Stat");
						exit(6);
					}
					errno = 0;
				}


				if (mkfifo(in_pool,PERMS) < 0){
					perror("mkfifo in_pool");
					exit(-2);
				}

			
				pid_t pid = -1;
				pid = fork();
				if(pid == 0){ 
					char id_str[15];
					sprintf(id_str,"%d",pool_table[k].id);
					char jobs_pool_str[15];
					sprintf(jobs_pool_str,"%d",jobs_pool);
					char process_id_str[15];
					sprintf(process_id_str,"%d",process_id);
					execl("./pool","./pool",job,(char*)id_str,(char*)jobs_pool_str,(char*)process_id_str,(char*)NULL);
					printf("return not expected \n");
				}
				else if ( pid < 0 ){
					perror("Fork");
					exit(-8);
				}
				else ;		
				
				char* command = calloc(strlen(job),1);
				strcpy(command,job);
				command = strtok(command," ");
				if(strcmp(command,"submit") == 0){
					process_id += jobs_pool;
				}		
			
				int fd_pool_in;
				if ( (fd_pool_in = open(in_pool,O_WRONLY,PERMS) ) < 0 ){
					perror("open in_pool");
					exit(-3);
				}
			
				int j;
				for(j = 0 ; j < MAXPOOLS * MAXREAD ; j++)response[j]=0;
				while(read(fd_pool_out,response,MAXREAD) < 0);
				pool_table[k].capacity--;
				pool_id++;
				if ( close(fd_pool_in) < 0 ){
					perror("Close fd_pool_in");
					exit(2);
				}	
				if ( close(fd_pool_out) < 0 ){
					perror("Close fd_out");
					exit(2);
				}	
			}
			else{	
				char* command = calloc(strlen(job),1);
				strcpy(command,job);
				command = strtok(command," \n");
				int search_pool = k;
				if(strcmp(command,"submit") == 0){
					pool_table[pool_id].capacity--;
				}	
				else if(strcmp(command,"status") == 0){
					strcpy(command,job);
					strtok(command," ");
					command = strtok(NULL,"\n");
					search_pool = (atoi(command)/jobs_pool );
				}
				else ;



				if(strcmp(command,"status-all") == 0){
					int i;
					char temp[MAXREAD];
					char old_response[MAXPOOLS*MAXREAD];
					for(i = 0 ; i < pool_id + 1; i++){
						search_pool = i;
						char* in_pool = calloc(strlen("in_pool")+3,1);
						if(in_pool == NULL){
							perror("Memory Allocation");
							exit(5);
						}

						if( sprintf(in_pool,"in_pool%d",search_pool) < 0 ){
							perror("sprintf");
							exit(14);
						}

						int fd_pool_in = open(in_pool,O_WRONLY,PERMS);
						if(fd_pool_in < 0 ){
							perror("Open");
							exit(-22);
						}
						if ( write(fd_pool_in,job,strlen(job)+1) < 0 ){
							perror("write");
							exit(55);
						}

						char* out_pool = calloc(strlen("out_pool")+3,1);
						if(out_pool == NULL){
							perror("Memory Allocation");
							exit(5);
						}

						if( sprintf(out_pool,"out_pool%d",search_pool) < 0 ){
							perror("sprintf");
							exit(14);
						}


						int fd_pool_out = open(out_pool,O_RDONLY|O_NONBLOCK,PERMS);
						if(fd_pool_out < 0 ){
							perror("Open");
							exit(-22);
						}

						
						int l;
						for(l = 0 ; l < MAXREAD ; l++)temp[l] = 0;
						if( i == 0){
							for(l = 0 ; l < MAXPOOLS* MAXREAD ; l++){
								response[l]=0;
								old_response[l] = 0;
							}
						}



						while(read(fd_pool_out,temp,MAXREAD) < 0);
						if( i == 0){
							strcpy(old_response,temp);
							strcpy(response,old_response);
						}
						else {
							sprintf(response,"%s\n%s",old_response,temp);
							strcpy(old_response,response);
						}
						if ( close(fd_pool_in) < 0 ){
							perror("Close fd_pool_in");
							exit(2);
						}	
						if ( close(fd_pool_out) < 0 ){
							perror("Close fd_out");
							exit(2);
						}	
					}
				}
				else {

					char* in_pool = calloc(strlen("in_pool")+3,1);
					if(in_pool == NULL){
						perror("Memory Allocation");
						exit(5);
					}

					if( sprintf(in_pool,"in_pool%d",search_pool) < 0 ){
						perror("sprintf");
						exit(14);
					}

					int fd_pool_in = open(in_pool,O_WRONLY,PERMS);
					if(fd_pool_in < 0 ){
						perror("Open");
						exit(-22);
					}
					if ( write(fd_pool_in,job,strlen(job)+1) < 0 ){
						perror("write");
						exit(55);
					}

					char* out_pool = calloc(strlen("out_pool")+3,1);
					if(out_pool == NULL){
						perror("Memory Allocation");
						exit(5);
					}

					if( sprintf(out_pool,"out_pool%d",search_pool) < 0 ){
						perror("sprintf");
						exit(14);
					}


					int fd_pool_out = open(out_pool,O_RDONLY|O_NONBLOCK,PERMS);
					if(fd_pool_out < 0 ){
						perror("Open");
						exit(-22);
					}

					int p;

					for(p = 0 ; p < MAXPOOLS * MAXREAD ;p++ ){
						response[p] = 0;
					}
					while(read(fd_pool_out,response,MAXREAD) < 0);
					if ( close(fd_pool_in) < 0 ){
						perror("Close fd_pool_in");
						exit(2);
					}	
					if ( close(fd_pool_out) < 0 ){
						perror("Close fd_out");
						exit(2);
					}	

				}	

			}

		}
		if ( (job = strtok(NULL,"  ") ) < 0 ){
			perror("strtok");
			exit(-5);
		}
		write(fd_out,response,MAXREAD);
		strtok(NULL,"\n");
	}
	


	if(charbuf)free(charbuf);
	if(pool_table)free(pool_table);

	if(errno < 0){
		perror("Unexpected Behaviour");
		exit(10);
	}

	if ( close(fd_in) < 0 ){
		perror("Close fd_in");
		exit(2);
	}	

	printf("coord exiting\n");
	exit(0);
}