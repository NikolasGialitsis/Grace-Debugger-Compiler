#ifndef HEADER_H
#define HEADER_H

	#define MAXREAD 500
	#define MAXPOOLS 100
	#define PERMS 0777
	#define ACTIVE 1
	#define FINISHED 0
	#define SUSPENDED -1
	#define STOPPED -2
	typedef struct Pool{
		int id;
		int capacity;
	}Pool;


	typedef struct Job{
		int id;
		pid_t pid;
		int status;
	}Job;

#endif